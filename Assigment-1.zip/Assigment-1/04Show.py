import mysql.connector

con = mysql.connector.connect(host='localhost', user='root', password='1234', database='bookstoredb')
curs = con.cursor()

curs.execute("select * from book")

rec = curs.fetchall()

for row in rec:
    rec = curs.fetchall()
    print("Book Code : ", row[0])
    print("Book Name : ", row[1])
    print("Author : ", row[2])
    print("Publication : ", row[3])
    print("Edition : ", row[4])
    print("Price : ", row[5])
    print("Review : ", row[6])
    print()

    print("Total Number of Rows Retreived=", curs.rowcount)

con.close()