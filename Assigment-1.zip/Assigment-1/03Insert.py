import mysql.connector as mycon

con = mycon.connect(host='localhost',user='root',password='1234',database='bookstoredb')
curs = con.cursor()

try:
    bc = int(input('Enter Book Code : '))
    bn = input('Enter Book Name : ')
    ca = input('Enter Category : ')
    au = input('Enter Author : ')
    pb = input('Enter Publication : ')
    ed = input('Enter Edition : ')
    pr = int(input('Enter Price : '))

    curs.execute("insert into book values(%d,'%s','%s','%s','%s','%s',%d)" %(bc,bn,ca,au,pb,ed,pr))
    con.commit()
    print('Book added successfully')
except:
    print('Error inserting data...')

con.close()