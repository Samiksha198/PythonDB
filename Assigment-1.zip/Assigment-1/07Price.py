import mysql.connector as mycon

con = mycon.connect(host='localhost',user='root',password='1234',database='bookstoredb')
curs = con.cursor()

ebc = int(input('Enter Book Code : '))
curs.execute("select price from book where bookcode=%d" % (ebc,))
rec = curs.fetchone()

try :
    print("Book Price : %d" % rec[0])
    amt = int(input('Enter New Price : '))
    curs.execute("update book set price=%d where bookcode=%d" % (amt, ebc,))
    con.commit()
    print('Price updated successfully')

except :
    print('Book doesnt Not found')

con.close()