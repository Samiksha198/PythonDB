import mysql.connector as mycon

con = mycon.connect(host='localhost', user='root', password='1234', database='bookstoredb')
curs = con.cursor()

ebc = input('Enter Category : ')

curs.execute("select bookname from book where category='%s'" % (ebc,))
rec = curs.fetchall()

for row in rec:
    rec = curs.fetchall()
    print("Book Name : ", row[0])
    print()

print("Total Number of Rows Retreived=", curs.rowcount)

con.close()