import mysql.connector

con = mysql.connector.connect(host='localhost', user='root', password='1234', database='bookstoredb')
curs = con.cursor()

au = input('Enter Author : ')
pb = input('Enter Publication : ')

curs.execute("select * from book where author='%s' and publication='%s'" % (au, pb))
rec = curs.fetchall()

try:
    for row in rec:
        rec = curs.fetchall()
        print("Book Name : ", row[1])
        print()

    print("Total Number of Rows Retreived=", curs.rowcount)

except:
    print('Book Not found')

con.close()