import mysql.connector as mycon

con = mycon.connect(host='localhost', user='root', password='1234', database='bookstoredb')
curs = con.cursor()

ebc = int(input('Enter Book Code : '))

curs.execute("select bookname,category,author,publication,edition,price from book where bookcode=%d" % ebc)
rec = curs.fetchone()

try:
    print("Book Name : %s" % rec[0])
    print("Category : %s" % rec[1])
    print("Author : %s" % rec[2])
    print("Publication : %s" % rec[3])
    print("Edition : %s" % rec[4])
    print("Price : %d" % rec[5])
except:
    print('Not found')

con.close()