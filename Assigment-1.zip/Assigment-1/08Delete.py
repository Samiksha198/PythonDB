import mysql.connector

con=mysql.connector.connect(host='localhost',user='root',password='1234',database='bookstoredb')
curs=con.cursor()

ebc = int(input('Enter Book Code : '))

curs.execute("select bookname,category,author,publication,edition,price from book where bookcode=%d" % ebc)
rec = curs.fetchone()

try:
    print("Book Name : %s" % rec[0])
    print("Category : %s" % rec[1])
    print("Author : %s" % rec[2])
    print("Publication : %s" % rec[3])
    print("Edition : %s" % rec[4])
    print("Price : %d" % rec[5])

    if rec:
        tr = input('Enter transaction (yes/no) : ')
        if tr.lower().startswith('y'):
            curs.execute("delete from book where bookcode=%d" % ebc)
            con.commit()
            print('Book deleted successfully')
        else:
            print('Thanks')
    else:
        print('Invalid Input...')

except:
    print('Book Not found')

con.close()