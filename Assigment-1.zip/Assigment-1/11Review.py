import mysql.connector as mycon

con = mycon.connect(host='localhost', user='root', password='1234', database='bookstoredb')
curs = con.cursor()

ebc = int(input('Enter Book Code : '))
curs.execute("select price from book where bookcode = %d" % (ebc,))
rec = curs.fetchone()

try :
    rev = input('Write a Review : ')
    curs.execute("update book set review = '%s' where bookcode = %d" % (rev, ebc,))
    con.commit()
    print('Review updated successfully')

except :
    print('Book doesnt Not found')

con.close()